window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}

let elementsArray = document.querySelectorAll(".tile");
console.log(elementsArray);
window.addEventListener('scroll', fadeIn ); 
function fadeIn() {
    for (var i = 0; i < elementsArray.length; i++) {
        var elem = elementsArray[i]
        var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
        if (distInView < 0) {
            elem.classList.add("inView");
        } else {
            elem.classList.remove("inView");
        }
    }
}
fadeIn();

const observer = new IntersectionObserver((entries) => {
          entries.forEach((entry) => {
                if (entry.isIntersecting) {
                      entry.target.classList.add('appear');
                } else {
                      entry.target.classList.remove('appear');
                }
          });
    });

const nonVisableItext = document.querySelectorAll('.fadein');
nonVisableItext.forEach((el) => observer.observe(el));