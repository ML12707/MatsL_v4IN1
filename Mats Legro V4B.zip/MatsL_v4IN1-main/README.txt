---README---
Het aantal woorden kunt u terug vinden in de word
documenten in de map.